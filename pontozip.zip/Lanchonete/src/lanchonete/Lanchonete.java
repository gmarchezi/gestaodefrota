/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanchonete;

/**
 *
 * @author 20161bsi0012
 */
public class Lanchonete {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pedido pedido = new Pedido(13,0);
        for(int i=0;i<5;i++){
            Produto produto = new Produto("hamburger",5.00,1);
            ItemPedido itemPedido = new ItemPedido(2,produto);
            pedido.adicionarItem(itemPedido); 
        }
        System.out.println("Valor total: " + pedido.getValorTotal());
        
        
        
        
    }
    
    
    
    
}
