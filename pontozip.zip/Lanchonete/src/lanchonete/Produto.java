 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanchonete;

/**
 *
 * @author 20161bsi0012
 */
public class Produto {
    protected String nome;
    protected double valor;
    protected int id;
    
    public Produto(String nome, double valor, int id){
        this.nome = nome;
        this.valor = valor;
        this.id = id;
    }

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}
