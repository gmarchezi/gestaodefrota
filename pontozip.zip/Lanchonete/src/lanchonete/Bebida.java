/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanchonete;

/**
 *
 * @author 20161bsi0012
 */
public class Bebida extends Produto{
    private String sabor;
    private String tamanho;
    
    public Bebida(String sabor, String tamanho,String nome, float valor, int id){
        super(nome,valor,id);
        this.sabor = sabor;
        this.tamanho = tamanho;
    }
}
